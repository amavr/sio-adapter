'use strict';

const path = require('path');
const CONST = require('./resources/const.json');
const cfg = require('../config');
const FileHelper = require('./helpers/file_helper');

class Statistics {

    constructor() {
        process.stdin.resume();

        const context = this;
        this.event_counters = {
            dt_beg: new Date().toISOString()
        };

        //do something when app is closing
        process.on('beforeExit', this.exitHandler.bind(null, { cleanup: true }));

        //do something when app is closing
        process.on('exit', this.exitHandler.bind(null, { cleanup: true }));

        //catches ctrl+c event
        process.on('SIGINT', this.exitHandler.bind(null, { exit: true }));

        // catches "kill pid" (for example: nodemon restart)
        process.on('SIGUSR1', this.exitHandler.bind(null, { exit: true }));
        process.on('SIGUSR2', this.exitHandler.bind(null, { exit: true }));

        //catches uncaught exceptions
        process.on('uncaughtException', this.exitHandler.bind(null, { exit: true }));

        setInterval(() => {
            console.log(JSON.stringify(context.event_counters));
        }, 5000);
    }

    exitHandler(options, exitCode) {
        // this.save(exitCode);

        if (options.cleanup) console.log('clean');
        if (exitCode || exitCode === 0) console.log(exitCode);
        if (options.exit) process.exit();
    }


    async onEvent(eventName, sender, data) {
        console.log(`event: ${eventName}, ${sender.constructor.name}`);
        await this.addEvent(eventName, sender);
    }

    async addEvent(eventName, sender) {
        if (this.event_counters[eventName] === undefined) {
            this.event_counters[eventName] = 0;
        }
        this.event_counters[eventName]++;
    }

    async save(code) {
        await FileHelper.saveObjAsync(path.join(cfg.log_dir, 'event_counters.json'), context.event_counters);
    }
}

module.exports = new Statistics();